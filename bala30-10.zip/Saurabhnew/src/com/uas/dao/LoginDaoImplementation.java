package com.uas.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.uas.bean.ProgramBean;

@Repository
@Transactional
public class LoginDaoImplementation implements ILoginDao {

	@PersistenceContext
	private EntityManager entitymanager;
	
/*	@Override
	public ArrayList<ProgramBean> viewAllProName() {
		Query proNameQuery= entitymanager.createQuery("select p.programName from ProgramBean p ");
		return  (ArrayList<ProgramBean>) proNameQuery.getResultList();		
	}*/
	@Override
	public ArrayList<ProgramBean> getAllPro() {
		Query proName = entitymanager.createQuery("select p.programName from ProgramBean p");
		return (ArrayList<ProgramBean>) proName.getResultList();
	}

}
