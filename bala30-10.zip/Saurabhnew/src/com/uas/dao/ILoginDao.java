package com.uas.dao;

import java.util.ArrayList;

import com.uas.bean.ProgramBean;

public interface ILoginDao {

	ArrayList<ProgramBean> getAllPro();
	

}
