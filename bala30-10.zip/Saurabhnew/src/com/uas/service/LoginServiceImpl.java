package com.uas.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uas.bean.ProgramBean;
import com.uas.dao.ILoginDao;



@Service
public class LoginServiceImpl implements ILoginService
{
	@Autowired
	private ILoginDao ilogindao;

	@Override
	public boolean validateLoginDetails(String usr, String pass, String role) 
	{
		if(role.equals("admin"))
		{
		if(usr.equals("admin") && pass.equals("admin"))
		{
			return true;
		}
		else
		{
			 return false;
		}
		}

		return false;
			
		
	}

	@Override
	public boolean validateLoginDetails2(String usr, String pass,String role) {
		if(role.equals("mac"))
		{
		if(usr.equals("mac") && pass.equals("mac"))
		{
			return true;
		}
		else
		{
			if(usr.equals("admin") && pass.equals("admin"))
			 return false;
		}
		}
		
		
				return false;
			
		
	}

	@Override
	public ArrayList<ProgramBean> getAllPro() {
		return ilogindao.getAllPro();
	}

	

}

	


